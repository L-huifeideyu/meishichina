<template>
    <div id="main">
        <div id="header">
            <a href="#"><img src="img/mofang_img/big1.jpg" alt=""/></a>
        </div>
        <!--文字部分-->
        <div id="body">
            <div class="header1">
                <ul class="collect">
                    <li class="fav"><a title="收藏" href="#" ><i></i><span>518</span>人收藏</a></li>
                    <li class="shar1"><a title="分享到微信" href="#"><i></i>微信</a></li>
                    <li class="shar2"><a title="分享到QQ好友" href="#"><i></i>QQ好友</a></li>
                    <li class="shar3"><a title="分享到新浪微博" href="#"><i></i>新浪微博</a></li>
                </ul>
                <p id="p1">浆果是果实的一种类型，是由子房或联合其他花器发育成柔软多汁的肉质果。属于单果，常见于分属于不同科属的多种植物。浆果的外果皮较薄，一枚果实中常有许多种子，浆果类果树种类很多，如葡萄、猕猴桃、树莓、无花果、石榴、杨桃、、番木瓜、番石榴、蓝莓、西番莲等。</p>
            </div>
            <div class="title">
                <h2><img src="img/mofang_img/mo.png" alt=""/>"水果皇后"－蓝莓</h2>
            </div>
            <p>蓝莓起源于北美，多年生灌木小浆果果树。因果实呈蓝色，故称为蓝莓。蓝莓果肉细腻，风味独特，酸甜适度，又具有香爽宜人的香气。其营养丰富，花青素含量十分丰富，具有抗衰老的功效。此外，蓝莓中蛋白质、矿物质、微量元素也相当可观。</p>
            <div class="img">
                <ul>
                    <li>
                        <div>
                            <a title="爆浆蓝莓餐包的做法" href="#"><span class="copyright">独家</span><img class="Img" src="img/mofang_img/1.jpg" alt=""/><span>爆浆蓝莓餐包</span>
                            </a>
                        </div>
                    </li>
                    <li><div><a title="蓝莓山药泥的做法" href="#"><span class="copyright">独家</span><img class="Img" src="img/mofang_img/2.jpg" alt=""/><span>蓝莓山药泥</span></a></div></li>
                    <li><div><a title="蓝莓果酱夹心饼干的做法" href="#"><img class="Img" src="img/mofang_img/3.jpg" alt=""/><span>蓝莓果酱夹心饼干</span></a></div></li>
                    <li><div><a title="蓝莓奶酪纸杯蛋糕的做法" href="#"><img class="Img" src="img/mofang_img/4.jpg" alt=""/><span>蓝莓奶酪纸杯蛋糕</span></a></div></li>
                    <li><div><a title="蓝莓酱费南雪的做法" href="#"><img class="Img" src="img/mofang_img/5.jpg" alt=""/><span>蓝莓酱费南雪</span></a></div></li>
                    <li><div><a title="芝士蓝莓派的做法" href="#"><img class="Img" src="img/mofang_img/6.jpg" alt=""/><span>芝士蓝莓派</span></a></div></li>
                    <li><div><a title="一杯子装满蓝莓的香甜的做法" href="#"><img class="Img" src="img/mofang_img/7.jpg" alt=""/><span>一杯子装满蓝莓的香甜</span></a></div></li>
                    <li><div><a title="蓝莓雪梨的做法" href="#"><img class="Img" src="img/mofang_img/8.jpg" alt=""/><span>蓝莓雪梨</span></a></div></li>
                    <li><div><a title="蓝莓果酱的做法" href="#"><img class="Img" src="img/mofang_img/9.jpg" alt=""/><span>蓝莓果酱</span></a></div></li>
                    <li><div><a title="炭烧蓝莓燕麦饮的做法" href="#"><img class="Img" src="img/mofang_img/10.jpg" alt=""/><span>炭烧蓝莓燕麦饮</span></a></div></li>
                    <li><div><a title="蓝莓慕斯蛋糕的做法" href="#"><img class="Img" src="img/mofang_img/11.jpg" alt=""/><span>蓝莓慕斯蛋糕</span></a></div></li>
                    <li><div><a title="蓝莓香蕉麦片的做法" href="#"><img class="Img" src="img/mofang_img/12.jpg" alt=""/><span>蓝莓香蕉麦片</span></a></div></li>
                </ul>
            </div>
            <div class="title">
                <h2><img src="img/mofang_img/mo.png" alt=""/>“水晶明珠”－葡萄</h2>
            </div>
            <p>葡萄属木质藤本植物，是世界最古老的果树树种之一。浆果多为圆形或椭圆，色泽随品种而异。葡萄不仅味美可口，而且营养价值很高。成熟的浆果中葡萄含糖量高达10%-30%，葡萄中的多种果酸有助于消化，适当多吃些葡萄，能健睥和胃。鲜葡萄中的黄酮类物质，能“清洗”血液，若将葡萄皮和葡萄籽一起食用，对心脏的保护作用更佳。</p>
            <div class="img">
                <ul>
                    <li><div><a title="葡萄奶酥的做法" href="#"><img class="Img" src="img/mofang_img/13.jpg" alt=""/><span>葡萄奶酥</span></a></div></li>
                    <li><div><a title="蜜豆葡萄干松饼的做法" href="#"><img class="Img" src="img/mofang_img/14.jpg" alt=""/><span>蜜豆葡萄干松饼</span></a></div></li>
                    <li><div><a title="葡萄麦芽糖葫芦的做法" href="#"><img class="Img" src="img/mofang_img/15.jpg" alt=""/><span>葡萄麦芽糖葫芦</span></a></div></li>
                    <li><div><a title="加州葡萄干鸡肉沙拉的做法" href="#"><img class="Img" src="img/mofang_img/16.jpg" alt=""/><span>加州葡萄干鸡肉沙拉</span></a></div></li>
                    <li><div><a title="葡萄干哈雷蛋糕的做法" href="#"><img class="Img" src="img/mofang_img/17.jpg" alt=""/><span>葡萄干哈雷蛋糕</span></a></div></li>
                    <li><div><a title="紫葡萄果酱的做法" href="#"><img class="Img" src="img/mofang_img/18.jpg" alt=""/><span>紫葡萄果酱</span></a></div></li>
                    <li><div><a title="鸡尾酒葡萄果汁的做法" href="#"><img class="Img" src="img/mofang_img/19.jpg" alt=""/><span>鸡尾酒葡萄果汁</span></a></div></li>
                    <li><div><a title="葡萄汁的做法" href="#"><img class="Img" src="img/mofang_img/20.jpg" alt=""/><span>葡萄汁</span></a></div></li>
                    <li><div><a title="鲜榨蜜蜂葡萄饮的做法" href="#"><img class="Img" src="img/mofang_img/21.jpg" alt=""/><span>鲜榨蜜蜂葡萄饮</span></a></div></li>
                    <li><div><a title="香甜葡萄香蕉奶昔的做法" href="#"><img class="Img" src="img/mofang_img/22.jpg" alt=""/><span>香甜葡萄香蕉奶昔</span></a></div></li>
                    <li><div><a title="加州葡萄干南瓜燕麦粥的做法" href="#"><img class="Img" src="img/mofang_img/23.jpg" alt=""/><span>加州葡萄干南瓜燕麦粥</span></a></div></li>
                    <li><div><a title="西瓜葡萄冻的做法" href="#"><img class="Img" src="img/mofang_img/24.jpg" alt=""/><span>西瓜葡萄冻</span></a></div></li>
                </ul>
            </div>
            <div class="title">
                <h2><img src="img/mofang_img/mo.png" alt=""/>“维C之王”－猕猴桃</h2>
            </div>
            <p>猕猴桃因为果皮覆毛，貌似猕猴而得名，是一种品质鲜嫩，营养丰富，风味鲜美的水果。其质地柔软，口感酸甜。味道被描述为草莓、香蕉、菠萝三者的混合。猕猴桃含有丰富的微量元素和人体所需17种氨基酸，还含有丰富的维生素C。据了解，一颗猕猴桃能提供一个人一日维生素C需求量的两倍多。</p>
            <div class="img">
                <ul>
                    <li><div><a title="猕猴桃雪梨汁的做法" href="#"><img class="Img" src="img/mofang_img/25.jpg" alt=""/><span>猕猴桃雪梨汁</span></a></div></li>
                    <li><div><a title="自制猕猴桃干的做法" href="#"><img class="Img" src="img/mofang_img/26.jpg" alt=""/><span>自制猕猴桃干</span></a></div></li>
                    <li><div><a title="猕猴桃果酱的做法" href="#"><img class="Img" src="img/mofang_img/27.jpg" alt=""/><span>猕猴桃果酱</span></a></div></li>
                    <li><div><a title="猕猴桃奶油蛋糕卷的做法" href="#"><img class="Img" src="img/mofang_img/28.jpg" alt=""/><span>猕猴桃奶油蛋糕卷</span></a></div></li>
                    <li><div><a title="猕猴桃玛芬的做法" href="#"><img class="Img" src="img/mofang_img/29.jpg" alt=""/><span>猕猴桃玛芬</span></a></div></li>
                    <li><div><a title="猕猴桃银耳羹的做法" href="#"><img class="Img" src="img/mofang_img/30.jpg" alt=""/><span>猕猴桃银耳羹</span></a></div></li>
                    <li><div><a title="青提猕猴桃思慕雪的做法" href="#"><img class="Img" src="img/mofang_img/31.jpg" alt=""/><span>青提猕猴桃思慕雪</span></a></div></li>
                    <li><div><a title="猕猴桃蓝莓奶昔的做法" href="#"><img class="Img" src="img/mofang_img/32.jpg" alt=""/><span>猕猴桃蓝莓奶昔</span></a></div></li>
                </ul>
            </div>
            <div class="title">
                <h2><img src="img/mofang_img/mo.png" alt=""/>“第三代水果之王”－树莓</h2>
            </div>
            <p>树莓又名山梅，是直立灌木类，其果实果味甜美，含糖、苹果酸、柠檬酸及维生素C等，可供生食、制果酱及酿酒。树莓浆果所含的各种营养成份易被人体吸收，具有促进对其他营养物质的吸收和消化，改善新陈代谢、增强抗病的作用。</p>
            <div class="img">
                <ul>
                    <li><div><a title="树莓奶酪夹馅小贝的做法" href="#"><img class="Img" src="img/mofang_img/33.jpg" alt=""/><span>树莓奶酪夹馅小贝</span></a></div></li>
                    <li><div><a title="树莓之恋慕斯的做法" href="#"><img class="Img" src="img/mofang_img/34.jpg" alt=""/><span>树莓之恋慕斯</span></a></div></li>
                    <li><div><a title="树莓果酱的做法" href="#"><span class="copyright">独家</span><img class="Img" src="img/mofang_img/35.jpg" alt=""/><span>树莓果酱</span></a></div></li>
                    <li><div><a title="葡萄干荔枝树莓布丁的做法" href="#"><img class="Img" src="img/mofang_img/36.jpg" alt=""/><span>葡萄干荔枝树莓布丁</span></a></div></li>
                    <li><div><a title="酸奶树莓慕斯的做法" href="#"><img class="Img" src="img/mofang_img/37.jpg" alt=""/><span>酸奶树莓慕斯</span></a></div></li>
                    <li><div><a title="抹茶树莓挞的做法" href="#"><img class="Img" src="img/mofang_img/38.jpg" alt=""/><span>抹茶树莓挞</span></a></div></li>
                    <li><div><a title="树莓慕斯的做法" href="#"><img class="Img" src="img/mofang_img/39.jpg" alt=""/><span>树莓慕斯</span></a></div></li>
                    <li><div><a title="树莓夹心饼干的做法" href="#"><img class="Img" src="img/mofang_img/40.jpg" alt=""/><span>树莓夹心饼干</span></a></div></li>
                </ul>
            </div>
            <div class="title">
                <h2><img src="img/mofang_img/mo.png" alt=""/>“天堂之果”－无花果</h2>
            </div>
            <p>无花果是一种开花植物，主要生长于一些热带和温带的地方，属亚热带落叶小乔木。无花果除鲜食、药用外，还可加工制干、制果脯、果酱、果汁、果茶、果酒、饮料、罐头等。无花果干无任何化学添加剂，味道浓厚、甘甜。无花果汁、饮料具有独特的清香味，生津止渴，老幼皆宜。</p>
            <div class="img">
                <ul>
                    <li><div><a title="无花果挞的做法" href="#"><img class="Img" src="img/mofang_img/41.jpg" alt=""/><span>无花果挞</span></a></div></li>
                    <li><div><a title="油炸无花果的做法" href="#"><img class="Img" src="img/mofang_img/42.jpg" alt=""/><span>油炸无花果</span></a></div></li>
                    <li><div><a title="无花果挞的做法" href="#"><img class="Img" src="img/mofang_img/43.jpg" alt=""/><span>无花果挞</span></a></div></li>
                    <li><div><a title="无花果塔的做法" href="#"><img class="Img" src="img/mofang_img/44.jpg" alt=""/><span>无花果塔</span></a></div></li>
                    <li><div><a title="椰蓉无花果玫瑰卷的做法" href="#"><img class="Img" src="img/mofang_img/45.jpg" alt=""/><span>椰蓉无花果玫瑰卷</span></a></div></li>
                    <li><div><a title="无花果蓝莓玛德琳的做法" href="#"><img class="Img" src="img/mofang_img/46.jpg" alt=""/><span>无花果蓝莓玛德琳</span></a></div></li>
                    <li><div><a title="无花果挞的做法" href="#"><img class="Img" src="img/mofang_img/47.jpg" alt=""/><span>无花果挞</span></a></div></li>
                    <li><div><a title="无花果养颜茶的做法" href="#"><img class="Img" src="img/mofang_img/48.jpg" alt=""/><span>无花果养颜茶</span></a></div></li>
                    <li><div><a title="无花果银耳百合汽锅甜汤的做法" href="#"><img class="Img" src="img/mofang_img/49.jpg" alt=""/><span>无花果银耳百合汽锅甜汤</span></a></div></li>
                    <li><div><a title="无花果酥饼的做法" href="#"><img class="Img" src="img/mofang_img/50.jpg" alt=""/><span>无花果酥饼</span></a></div></li>
                    <li><div><a title="无花果芡实桂圆汤的做法" href="#"><img class="Img" src="img/mofang_img/51.jpg" alt=""/><span>无花果芡实桂圆汤</span></a></div></li>
                    <li><div><a title="无花果磅蛋糕的做法" href="#"><img class="Img" src="img/mofang_img/52.jpg" alt=""/><span>无花果磅蛋糕</span></a></div></li>
                </ul>
            </div>
            <div class="title">
                <h2><img src="img/mofang_img/mo.png" alt=""/>“知识之树”－石榴</h2>
            </div>
            <p>石榴属于球形浆果类，石榴果实如一颗颗红色的宝石，果粒酸甜可口多汁，营养价值高，富含丰富的水果糖类、优质蛋白质、易吸收脂肪等，可补充人体能量和热量，但不增加身体负担。其果实维生素C含量比苹果、梨要高出一二倍，性味甘、酸涩、温，具有杀虫、收敛、涩肠、止痢等功效。</p>
            <div class="img">
                <ul>
                    <li><div><a title="的做法" href="#"><span class="copyright">独家</span><img class="Img" src="img/mofang_img/53.jpg" alt=""/><span>石榴戚风蛋糕</span></a></div></li>
                    <li><div><a title="鲜榨石榴汁的做法" href="#"><img class="Img" src="img/mofang_img/54.jpg" alt=""/><span>鲜榨石榴汁</span></a></div></li>
                    <li><div><a title="石榴苹果果酱的做法" href="#"><img class="Img" src="img/mofang_img/55.jpg" alt=""/><span>石榴苹果果酱</span></a></div></li>
                    <li><div><a title="红心番石榴慕斯蛋糕的做法" href="#"><img class="Img" src="img/mofang_img/56.jpg" alt=""/><span>红心番石榴慕斯蛋糕</span></a></div></li>
                </ul>
            </div>
            <div class="title">
                <h2><img src="img/mofang_img/mo.png" alt=""/>“水果之皇”－木瓜</h2>
            </div>
            <p>木瓜鲜美兼具食疗作用，尤其对女性更有美容功效。木瓜所含的蛋白分解酵素，可以补偿胰和肠道的分泌，补充胃液的不足，有助于分解蛋白质和淀粉。木瓜含有胡萝卜素和丰富的维生素C，它们有很强的抗氧化能力，帮助机体修复组织，消除有毒物质，增强人体免疫力。</p>
            <div class="img">
                <ul>
                    <li><div><a title="冰糖炖木瓜的做法" href="#"><span class="copyright">独家</span><img class="Img" src="img/mofang_img/57.jpg" alt=""/><span>冰糖炖木瓜</span></a></div></li>
                    <li><div><a title="木瓜椰奶冻的做法" href="#"><img class="Img" src="img/mofang_img/58.jpg" alt=""/><span>木瓜椰奶冻</span></a></div></li>
                    <li><div><a title="木瓜酸奶杯的做法" href="#"><img class="Img" src="img/mofang_img/59.jpg" alt=""/><span>木瓜酸奶杯</span></a></div></li>
                    <li><div><a title="木瓜鲫鱼汤的做法" href="#"><img class="Img" src="img/mofang_img/60.jpg" alt=""/><span>木瓜鲫鱼汤</span></a></div></li>
                    <li><div><a title="木瓜燕窝炖雪蛤的做法" href="#"><img class="Img" src="img/mofang_img/61.jpg" alt=""/><span>木瓜燕窝炖雪蛤</span></a></div></li>
                    <li><div><a title="木瓜牛奶的做法" href="#"><img class="Img" src="img/mofang_img/62.jpg" alt=""/><span>木瓜牛奶</span></a></div></li>
                    <li><div><a title="木瓜椰汁西米露的做法" href="#"><img class="Img" src="img/mofang_img/63.jpg" alt=""/><span>木瓜椰汁西米露</span></a></div></li>
                    <li><div><a title="栗子瘦肉木瓜汤的做法" href="#"><img class="Img" src="img/mofang_img/64.jpg" alt=""/><span>栗子瘦肉木瓜汤</span></a></div></li>
                    <li><div><a title="木瓜银耳炖牛奶的做法" href="#"><img class="Img" src="img/mofang_img/65.jpg" alt=""/><span>木瓜银耳炖牛奶</span></a></div></li>
                    <li><div><a title="木瓜酸奶捞的做法" href="#"><span class="copyright">独家</span><img class="Img" src="img/mofang_img/66.jpg" alt=""/><span>木瓜酸奶捞</span></a></div></li>
                    <li><div><a title="木瓜鲜鸡汤的做法" href="#"><img class="Img" src="img/mofang_img/67.jpg" alt=""/><span>木瓜鲜鸡汤</span></a></div></li>
                    <li><div><a title="木瓜黄豆猪蹄汤的做法" href="#"><img class="Img" src="img/mofang_img/68.jpg" alt=""/><span>木瓜黄豆猪蹄汤</span></a></div></li>
                </ul>
            </div>
        </div>
        <!--底部-->
        <div id="footer">
            <div class="hr"></div>
            <div class="ft1">
                <p class="c1"><a href="#">美食天下 -让吃更美好!</a></p>
                <p class="c2">
                    <a title="菜谱" href="#">菜谱</a>•
                    <a title="食材" href="#">食材</a>•
                    <a title="魔方" href="#">魔方</a>•
                    <a title="关于我们" href="#">关于我们</a>•
                    <a title="联系我们" href="#">联系我们</a>•
                    <a title="加入我们" href="#">加入我们</a>•
                    <a title="服务声明" href="#">服务声明</a>•
                    <a title="友情链接" href="#">友情链接</a>•
                    <a title="网站地图" href="#">网站地图</a>•
                    <a title="移动应用" href="#">移动应用</a>
                </p>
                <p class="c3">© 2004-2018 美食天下 保留所有权利 - 京ICP证090244号</p>
            </div>
            <div class="ft3"><img title="微信公众号" src="img/mofang_img/weixin.png" alt="">微信公众号</div>
            <div class="ft2"><img title="手机客户端" src="img/mofang_img/msc_app.png" alt="">手机客户端</div>
            <div class="fixed-footer"><a title="点击返回页面顶部" href="#"><img src="img/mofang_img/gotop.png" alt=""></a></div>
        </div>
    </div>
</template>
<script>
    
</script>
<style scoped>
    *{
        margin:0;
        padding:0;
    }
    #body{
        width:1000px;
        margin:auto;
        padding:30px 0;
        overflow: hidden;
    }
    #body p{
        margin-bottom: 12px;
    }
    ul.collect{
        display:block;
        width:300px;
        margin:0 0 5px 10px;
        float:right;
    }
    .collect li{
        width:75px;
        height:53px;
        float:left;

    }

    .collect li a{
        text-decoration: none;
        display: block;
        text-align: center;
        white-space: nowrap;
        color: #999;
        font-size: 11px;
    }
    .collect li a i{
        width: 30px;
        height: 30px;
        display: block;
        margin: 2px auto;
        background-image: url("/../img/mofang_img/logo.png");
        background-size: 300px 30px;
    }
    .collect .fav a i{
        background-position:600px,30px;
    }
    .collect .fav a i:hover{
        background-position:570px,30px;
    }
    .collect .shar1 a i{
        background-position:450px,30px;
    }
    .collect .shar2 a i{
        background-position:510px,30px;
    }
    .collect .shar3 a i{
        background:url("/../img/mofang_img/logo.png")  540px,30px;
        background-size: 300px 30px;
    }
    ul{
        list-style:none;
    }
    #p1{
        width:690px;
        height:132px;
        background:#fff;
        font-size: 18px;
        color: #333;
        padding: 0 0 20px 0;
    }
    .title{
        color:#ff6767;
        font-size:20px;
        line-height: 20px;
        padding:20px 0 20px 25px;
        background:rgba(0,0,0,0)
    }
    .title h2{
        font-size: 100%;
        font-weight:400;
    }
    #body p{
        font-size:18px;
        color:#333;
        padding:0 0 20px 0;
    }
    .img li{
        float:left;
        width:230px;
    }
    .img ul li .copyright{
        background: rgba(0,0,0,.5);
        border-radius: 3px;
        color: #fff;
        font-size: 12px;
        height: 20px;
        left: 5px;
        line-height: 20px;
        padding: 1px 4px;
        position: absolute;
        top: 5px;
        z-index: 1;
    }
    .img div{
        display:block;
        width:230px;
        height:268px;
        text-align:center;
    }
    .img ul li{
        float: left;
        margin: 0 20px 20px 0;
        width: 230px;
        height: 268px;
        text-align: center;
        position: relative;
    }
    .img ul li a:hover span{
        color:#FF6761;
    }
    .img a{
        color: #333;
        text-decoration: none;
        cursor:pointer;
    }
    .img .Img{
        width: 230px;
        height: 230px;
        margin:auto;
    }
    .img span{
        color: #333;
        display: block;
        font-size: 18px;
        overflow: hidden;
        padding: 5px 0;
    }
    #footer{
        border-top:2px solid #e8e8e8;
        width:1000px;
        margin:auto;
        padding:10px 0;
        margin-bottom: 10px;
    }
    #footer .ft1{
        float: left;
        font-size: 11px;
        color: #666;
        width: 680px;
        padding-top: 10px;
    }
    #footer a{
        text-decoration: none;
    }
    #footer .ft1 p{
        margin-bottom:6px;
    }
    #footer .ft1 .c1 a{
        font-size:15px;
        color:#f50;
        font-weight:700;
    }
    #footer .ft1 .c1 a:hover{
        text-decoration: underline;
    }
    #footer .ft1 .c2 a{
        font-size:12px;
        color:#666;
        padding-right:2px;
    }
    #footer .ft1 .c2 a:hover{
        color:#f30;
        text-decoration: underline;
    }
    #footer .ft1 .c3{
        font-size:11px;
        color:#666;
    }
    .ft2,.ft3{
        clear:none;
        display:block;
        text-align:center;
    }
    #footer .ft2{
        width:82px;
        heifght:100;
        margin:0 798px;
        font-size:13px;
    }
    #footer .ft3{
        width:82px;
        heifght:100;
        float:right;
        margin:0;
        font-size:12px;
    }
    #footer .ft2 img{
        width:82px;
        height:82px;
        display:block;
    }
    #footer .fixed-footer{
        position: fixed;
        bottom: 10px;
        left: -999px;
        z-index: 102410;
        height: 58px;
    }

    
</style>