﻿
CREATE	TABLE topic(
	tid INT PRIMARY KEY AUTO_INCREMENT,
        userId INT,              #外键用户ID
	t_title VARCHAR(128),    #话题标题
	t_disc VARCHAR(256),     #话题描述
	FOREIGN KEY(userId) REFERENCES user(uid)
);

INSERT INTO topic VALUES(null,1,"#你好,美天#","#早餐#奥利奥牛轧糖");
INSERT INTO topic VALUES(null,1,"早餐","#早餐#美好的一天从早餐开始");
INSERT INTO topic VALUES(null,1,"#你好,美天#","#早餐#美好的一天从早餐开始");
INSERT INTO topic VALUES(null,1,"银耳红枣粥，蒸南瓜，煎蛋和鸡蛋葱花饼","#早餐#美好的一天从早餐开始");

INSERT INTO topic VALUES(null,2,"阳光明媚，花儿俏，早安啦","早餐");
INSERT INTO topic VALUES(null,2,"蜂蜜麻花","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,2,"午餐","美好的一天从早餐开始");

INSERT INTO topic VALUES(null,3,"午餐来了……","#午餐#鲜美的荠菜大餛饨");
INSERT INTO topic VALUES(null,3,"早餐","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,3,"秋意渐浓，念无恙……","#午餐#鲜美的荠菜大餛饨");

INSERT INTO topic VALUES(null,4,"早餐","#早餐# 面包 水果 牛奶");
INSERT INTO topic VALUES(null,4,"减肥餐","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,4,"银耳红枣粥，蒸南瓜，煎蛋和鸡蛋葱花饼","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,4,"生活","#早餐# 面包 水果 牛奶");

INSERT INTO topic VALUES(null,5,"打卡","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,5,"奥利奥牛轧糖","#早餐#继续，减肥餐");
INSERT INTO topic VALUES(null,5,"早餐","#早餐# 面包 水果 牛奶");
INSERT INTO topic VALUES(null,5,"生活","生活就像甜甜圈，不圆满才能叫生活；生活就像烤面包机，正面烤完......");


INSERT INTO topic VALUES(null,6,"打卡","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,6,"早餐","#早餐#继续，减肥餐");
INSERT INTO topic VALUES(null,6,"早餐","#早餐# 面包 水果 牛奶");
INSERT INTO topic VALUES(null,6,"生活","生活就像甜甜圈，不圆满才能叫生活；生活就像烤面包机，正面烤完......");
INSERT INTO topic VALUES(null,6,"银耳红枣粥，蒸南瓜，煎蛋和鸡蛋葱花饼","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,6,"早餐","#早餐# 面包 水果 牛奶");
INSERT INTO topic VALUES(null,6,"银耳红枣粥，蒸南瓜，煎蛋和鸡蛋葱花饼","美好的一天从早餐开始");

INSERT INTO topic VALUES(null,7,"早餐","#早餐#继续，减肥餐");
INSERT INTO topic VALUES(null,7,"私房日系料理","#早餐#早早上班，同事做好蔬菜粥，暖心又养胃");
INSERT INTO topic VALUES(null,7,"早餐","#早餐# 面包 水果 牛奶");
INSERT INTO topic VALUES(null,7,"蟹脚肉炒蛋","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,7,"早餐","#早餐#早早上班，同事做好蔬菜粥，暖心又养胃");
INSERT INTO topic VALUES(null,7,"蟹脚肉炒蛋","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,7,"早餐","#早餐#继续，减肥餐");

INSERT INTO topic VALUES(null,8,"银耳红枣粥，蒸南瓜，煎蛋和鸡蛋葱花饼","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,8,"私房日系料理","#早餐#早早上班，同事做好蔬菜粥，暖心又养胃");
INSERT INTO topic VALUES(null,8,"生活","生活就像甜甜圈，不圆满才能叫生活；生活就像烤面包机，正面烤完......");
INSERT INTO topic VALUES(null,8,"早餐","关东煮，日式炸可乐饼，咖喱鸡肉乌冬面，日式土豆沙拉，三文鱼肉");
INSERT INTO topic VALUES(null,8,"私房日系料理","#早餐#早早上班，同事做好蔬菜粥，暖心又养胃");
INSERT INTO topic VALUES(null,8,"早餐","关东煮，日式炸可乐饼，咖喱鸡肉乌冬面，日式土豆沙拉，三文鱼肉");

INSERT INTO topic VALUES(null,9,"早餐","#早餐#继续，减肥餐");
INSERT INTO topic VALUES(null,9,"银耳红枣粥，蒸南瓜，煎蛋和鸡蛋葱花饼","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,9,"早餐","#早餐#早早上班，同事做好蔬菜粥，暖心又养胃");
INSERT INTO topic VALUES(null,9,"早餐","关东煮，日式炸可乐饼，咖喱鸡肉乌冬面，日式土豆沙拉，三文鱼肉");

INSERT INTO topic VALUES(null,10,"早餐","蟹脚肉炒蛋");
INSERT INTO topic VALUES(null,10,"早餐","#早餐#继续，减肥餐");
INSERT INTO topic VALUES(null,10,"银耳红枣粥，蒸南瓜，煎蛋和鸡蛋葱花饼","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,10,"早餐","#早餐#早早上班，同事做好蔬菜粥，暖心又养胃");
INSERT INTO topic VALUES(null,10,"早餐","美好的一天从早餐开始");

INSERT INTO topic VALUES(null,11,"银耳红枣粥，蒸南瓜，煎蛋和鸡蛋葱花饼","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,11,"早餐","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,11,"早餐","关东煮，日式炸可乐饼，咖喱鸡肉乌冬面，日式土豆沙拉，三文鱼肉");

INSERT INTO topic VALUES(null,12,"银耳红枣粥，蒸南瓜，煎蛋和鸡蛋葱花饼","#早餐#早早上班，同事做好蔬菜粥，暖心又养胃");

INSERT INTO topic VALUES(null,13,"生活","生活就像甜甜圈，不圆满才能叫生活；生活就像烤面包机，正面烤完......");
INSERT INTO topic VALUES(null,14,"早餐","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,15,"银耳红枣粥，蒸南瓜，煎蛋和鸡蛋葱花饼","#早餐#早早上班，同事做好蔬菜粥，暖心又养胃");
INSERT INTO topic VALUES(null,16,"早餐","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,17,"早餐","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,18,"银耳红枣粥，蒸南瓜，煎蛋和鸡蛋葱花饼","#早餐#早早上班，同事做好蔬菜粥，暖心又养胃");
INSERT INTO topic VALUES(null,19,"早餐","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,19,"银耳红枣粥，蒸南瓜，煎蛋和鸡蛋葱花饼","#早餐#早早上班，同事做好蔬菜粥，暖心又养胃");
INSERT INTO topic VALUES(null,20,"早餐","美好的一天从早餐开始");

INSERT INTO topic VALUES(null,21,"早餐","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,22,"早餐","生活就像甜甜圈，不圆满才能叫生活；生活就像烤面包机，正面烤完......");

INSERT INTO topic VALUES(null,23,"早餐","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,24,"银耳红枣粥，蒸南瓜，煎蛋和鸡蛋葱花饼","#早餐#早早上班，同事做好蔬菜粥，暖心又养胃");
INSERT INTO topic VALUES(null,25,"早餐","美好的一天从早餐开始");

INSERT INTO topic VALUES(null,26,"早餐","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,27,"银耳红枣粥，蒸南瓜，煎蛋和鸡蛋葱花饼","#早餐#早早上班，同事做好蔬菜粥，暖心又养胃");
INSERT INTO topic VALUES(null,28,"早餐","生活就像甜甜圈，不圆满才能叫生活；生活就像烤面包机，正面烤完......");
INSERT INTO topic VALUES(null,29,"早餐","美好的一天从早餐开始");

INSERT INTO topic VALUES(null,29,"早餐","生活就像甜甜圈，不圆满才能叫生活；生活就像烤面包机，正面烤完......");

INSERT INTO topic VALUES(null,30,"银耳红枣粥，蒸南瓜，煎蛋和鸡蛋葱花饼","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,30,"银耳红枣粥，蒸南瓜，煎蛋和鸡蛋葱花饼","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,31,"银耳红枣粥，蒸南瓜，煎蛋和鸡蛋葱花饼","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,31,"银耳红枣粥，蒸南瓜，煎蛋和鸡蛋葱花饼","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,33,"银耳红枣粥，蒸南瓜，煎蛋和鸡蛋葱花饼","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,34,"银耳红枣粥，蒸南瓜，煎蛋和鸡蛋葱花饼","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,35,"银耳红枣粥，蒸南瓜，煎蛋和鸡蛋葱花饼","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,35,"早餐","美好的一天从早餐开始");
INSERT INTO topic VALUES(null,35,"早餐","美好的一天从早餐开始");
