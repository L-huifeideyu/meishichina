﻿
CREATE TABLE topic_pic(
	tp_Id INT PRIMARY KEY AUTO_INCREMENT, #话题图片id
	tp_src VARCHAR(128),  #话题图片
        topicId INT,          #外键：话题id
	FOREIGN KEY(topicId) REFERENCES topic(tid)  

);

INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor1_row1.jpg",1);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor1_row2.jpg",1);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor1_row3.jpg",1);

INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor2_row1.jpg",2);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor2_row2.jpg",2);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor2_row3.jpg",2);

INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor3_row1.jpg",3);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor3_row2.jpg",3);

INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row1.jpg",4);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",4);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row3.jpg",4);

INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor5_row1.jpg",5);

INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor6_row1.jpg",6);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor6_row2.jpg",6);

INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor7_row1.jpg",7);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor7_row2.jpg",7);

INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor8_row1.jpg",8);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor8_row2.jpg",8);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor8_row3.jpg",8);

INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor9_row1.jpg",9);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor9_row2.jpg",9);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor9_row3.jpg",9);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor9_row4.jpg",9);

INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor10_row1.jpg",10);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor10_row2.jpg",10);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor10_row3.jpg",10);

INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row1.jpg",11);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",11);

INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",12);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",13);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",14);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",15);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",16);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",17);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",18);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",19);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",20);

INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",21);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",22);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",23);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",24);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",25);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",26);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",27);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",27);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",28);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",29);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",30);

INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",31);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",32);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",33);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",34);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",35);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",36);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",37);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",38);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",39);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",40);

INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",41);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",42);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",43);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",44);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",45);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",46);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",47);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",48);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",49);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",50);

INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",51);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",52);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",53);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",54);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",55);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",56);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor4_row2.jpg",57);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",58);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",59);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",60);

INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",61);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",62);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",63);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",64);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",65);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",66);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",67);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",68);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",69);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",70);

INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",71);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",72);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",73);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",74);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",75);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",76);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",77);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",78);
INSERT INTO topic_pic VALUES(null,"http://localhost:3030/img/topic_img/floor11_row1.jpg",79);


